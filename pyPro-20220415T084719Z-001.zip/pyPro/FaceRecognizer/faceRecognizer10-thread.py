from threading import Thread
import time
def BigBox(color,l):
    while True:
        print(color,'Big Box is open',l)
        time.sleep(5)
        print(color,'Big Box is closed',l)
        time.sleep(5)
def SmallBox(color,l):
    while True:
       print(color,'small Box is open',l)
       time.sleep(1)
       print(color,'small Box is closed',l)
       time.sleep(1)
c='red'
x=4
b='blue'

bigBoxThread=Thread(target=BigBox,args=(c,x))
x=5
smallBoxThread=Thread(target=SmallBox,args=(b,x))
bigBoxThread.daemon=True
smallBoxThread.daemon=True
bigBoxThread.start()
smallBoxThread.start()
while True:
    pass
