import cv2
import numpy as np
import time
print(cv2.__version__)
dispW=640
dispH=480
flip=2
font=cv2.FONT_HERSHEY_SIMPLEX
dtav=0
#Uncomment These next Two Line for Pi Camera
camSet='nvarguscamerasrc !  video/x-raw(memory:NVMM), width=3264, height=2464, format=NV12, framerate=21/1 ! nvvidconv flip-method='+str(flip)+' ! video/x-raw, width='+str(dispW)+', height='+str(dispH)+', format=BGRx ! videoconvert ! video/x-raw, format=BGR ! appsink'
cam1= cv2.VideoCapture(camSet)

#Or, if you have a WEB cam, uncomment the next line
#(If it does not work, try setting to '1' instead of '0')
cam2=cv2.VideoCapture(0)
startTime=time.time()
while True:
    ret, frame1 = cam1.read()
    ret, frame2 = cam2.read()
    frame2=cv2.resize(frame2,(frame1.shape[1],frame1.shape[0]))
    frameCombined=np.hstack((frame1,frame2))
    dt=time.time()-startTime
    startTime=time.time()
    dtav=.9*dtav+.1*dt
    fps=1/dtav
    cv2.rectangle(frameCombined,(0,0),(130,40),(0,0,255),-1)
    cv2.putText(frameCombined,str(round(fps,1))+'FPS',(0,25),font,.75,(0,255,255),2)
    cv2.imshow('combo',frameCombined)
    cv2.moveWindow('combo',0,0)

    if cv2.waitKey(1)==ord('q'):
        break
cam1.release()
cam2.release()
cv2.destroyAllWindows()