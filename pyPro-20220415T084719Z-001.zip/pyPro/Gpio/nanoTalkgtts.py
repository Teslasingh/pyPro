import os
from gtts import gTTS
myText ='get ready player1.the play will be rough!'
myOutput=gTTS(text=myText, lang='en',slow=False)
myOutput.save('talk.mp3')
os.system('mpg123 talk.mp3')       #connected to internet
