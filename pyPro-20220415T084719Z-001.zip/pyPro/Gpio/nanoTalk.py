import os
import pyttsx3
engine=pyttsx3.init()
engine.setProperty('rate',150)
engine.setProperty('voice','english+m3') #f1 to f4 for female voice and m1 to m4 for male voice
text='Get ready player 1. the play will be rough'
engine.say(text)
engine.runAndWait()