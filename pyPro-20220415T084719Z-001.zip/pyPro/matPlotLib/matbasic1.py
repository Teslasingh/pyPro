import matplotlib.pyplot as plt
x=[1,2,3,4]
y=[3,4,5,6]
plt.plot(x,y,'g-*')
plt.show()