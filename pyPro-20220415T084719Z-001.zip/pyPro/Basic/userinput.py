import numpy as np
myNum=int(input("please input a number: "))
for i in range(0,myNum,1):
    print(i)
print("thats all folks")